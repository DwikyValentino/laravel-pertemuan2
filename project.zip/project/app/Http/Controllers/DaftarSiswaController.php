<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DaftarSiswaController extends Controller
{
    public function index(Request $request){
        $mahasiswa = [
            ['nama' => 'Andika', 'kelas' => '6A'],
            ['nama' => 'Anam', 'kelas' => '6A'],
            ['nama' => 'Faris', 'kelas' => '6A'],
            ['nama' => 'Irfan', 'kelas' => '6B'],
            ['nama' => 'Dwiky', 'kelas' => '6B'],
            ['nama' => 'Andi', 'kelas' => '6B'],
            ['nama' => 'Yusli', 'kelas' => '6B'],
            ['nama' => 'Ferian', 'kelas' => '6C'],
            ['nama' => 'Wijaya', 'kelas' => '6C'],
            ['nama' => 'Ivan', 'kelas' => '6D'],
        ];

        if($request->query('kelas')){
            $mahasiswa = array_filter($mahasiswa, function($kelas){
                return $kelas['kelas'] == request()->kelas;
            });
        }

        return view('daftarsiswa', compact('mahasiswa'));
    }

    public function show($daftarsiswa){
        $mahasiswa = [
            ['nama' => 'Andika', 'kelas' => '6A'],
            ['nama' => 'Anam', 'kelas' => '6A'],
            ['nama' => 'Faris', 'kelas' => '6A'],
            ['nama' => 'Irfan', 'kelas' => '6B'],
            ['nama' => 'Dwiky', 'kelas' => '6B'],
            ['nama' => 'Andi', 'kelas' => '6B'],
            ['nama' => 'Yusli', 'kelas' => '6B'],
            ['nama' => 'Ferian', 'kelas' => '6C'],
            ['nama' => 'Wijaya', 'kelas' => '6C'],
            ['nama' => 'Ivan', 'kelas' => '6D'],
        ];

        if($daftarsiswa){
            $mahasiswa = array_filter($mahasiswa, function($kelas){
                return $kelas['kelas'] == request()->segment(count(request()->segments()));
            });
        }
        return view('daftarsiswa', compact('mahasiswa'));
    }

}
